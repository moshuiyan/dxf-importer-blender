"""
DXF Importer for Blender

This module provides functionality to import DXF files into Blender.
"""

# Import the main importer class
from .importer.dxf_importer import DXFImporter

# Version information
__version__ = '0.1.0'

# Clean up namespace
__all__ = ['DXFImporter']
