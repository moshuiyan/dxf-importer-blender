import bpy
import sys
import subprocess
import os
import importlib
from pathlib import Path

def install_package(package):
    """Install a package using pip."""
    python_exe = Path(sys.prefix) / 'bin' / 'python.exe' if os.name == 'nt' else Path(sys.prefix) / 'bin' / 'python3'
    
    try:
        # Check if package is already installed
        importlib.import_module(package.split('>=')[0].split('==')[0])
        print(f"{package} is already installed")
        return True
    except ImportError:
        print(f"Installing {package}...")
        try:
            # Try installing with --user flag
            subprocess.check_call([str(python_exe), "-m", "pip", "install", "--user", package])
            print(f"Successfully installed {package}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error installing {package}: {e}")
            return False

def register():
    """Install required packages."""
    # Get the directory of the current addon
    addon_dir = Path(__file__).parent
    requirements_file = addon_dir / "requirements.txt"
    
    if not requirements_file.exists():
        print("Requirements file not found")
        return False
    
    # Read requirements
    with open(requirements_file, 'r') as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
    
    # Install each package
    success = True
    for req in requirements:
        if not install_package(req):
            success = False
    
    if success:
        print("All dependencies installed successfully")
    else:
        print("Some dependencies failed to install. Please check the console for details.")
    
    return success

if __name__ == "__main__":
    register()
